package org.training.service;

import java.util.List;

public interface TopSellableService {
    public List<String> getTopSellableProducts();
}
