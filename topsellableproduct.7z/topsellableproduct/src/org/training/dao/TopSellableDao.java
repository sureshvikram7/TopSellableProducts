package org.training.dao;

import java.util.List;

public interface TopSellableDao {

    public List<String> getTopSellableProducts();
}
