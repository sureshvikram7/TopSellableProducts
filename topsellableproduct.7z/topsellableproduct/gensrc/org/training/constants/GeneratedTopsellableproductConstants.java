/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at 21-Sep-2022, 9:56:06 PM                     ---
 * ----------------------------------------------------------------
 */
package org.training.constants;

/**
 * @deprecated since ages - use constants in Model classes instead
 */
@Deprecated(since = "ages", forRemoval = false)
@SuppressWarnings({"unused","cast"})
public class GeneratedTopsellableproductConstants
{
	public static final String EXTENSIONNAME = "topsellableproduct";
	public static class Attributes
	{
		public static class Product
		{
			public static final String ISTOPSELLABLE = "isTopSellable".intern();
		}
	}
	
	protected GeneratedTopsellableproductConstants()
	{
		// private constructor
	}
	
	
}
