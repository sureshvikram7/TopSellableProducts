/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at 21-Sep-2022, 9:56:06 PM                     ---
 * ----------------------------------------------------------------
 */
package org.training.jalo;

import de.hybris.platform.directpersistence.annotation.SLDSafe;
import de.hybris.platform.jalo.GenericItem;
import de.hybris.platform.jalo.Item;
import de.hybris.platform.jalo.Item.AttributeMode;
import de.hybris.platform.jalo.JaloSession;
import de.hybris.platform.jalo.SessionContext;
import de.hybris.platform.jalo.extension.Extension;
import de.hybris.platform.jalo.extension.ExtensionManager;
import de.hybris.platform.jalo.product.Product;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import org.training.constants.TopsellableproductConstants;

/**
 * Generated class for type <code>TopsellableproductManager</code>.
 */
@SuppressWarnings({"unused","cast"})
@SLDSafe
public class TopsellableproductManager extends Extension
{
	protected static final Map<String, Map<String, AttributeMode>> DEFAULT_INITIAL_ATTRIBUTES;
	static
	{
		final Map<String, Map<String, AttributeMode>> ttmp = new HashMap();
		Map<String, AttributeMode> tmp = new HashMap<String, AttributeMode>();
		tmp.put("isTopSellable", AttributeMode.INITIAL);
		ttmp.put("de.hybris.platform.jalo.product.Product", Collections.unmodifiableMap(tmp));
		DEFAULT_INITIAL_ATTRIBUTES = ttmp;
	}
	@Override
	public Map<String, AttributeMode> getDefaultAttributeModes(final Class<? extends Item> itemClass)
	{
		Map<String, AttributeMode> ret = new HashMap<>();
		final Map<String, AttributeMode> attr = DEFAULT_INITIAL_ATTRIBUTES.get(itemClass.getName());
		if (attr != null)
		{
			ret.putAll(attr);
		}
		return ret;
	}
	
	public static final TopsellableproductManager getInstance()
	{
		ExtensionManager em = JaloSession.getCurrentSession().getExtensionManager();
		return (TopsellableproductManager) em.getExtension(TopsellableproductConstants.EXTENSIONNAME);
	}
	
	@Override
	public String getName()
	{
		return TopsellableproductConstants.EXTENSIONNAME;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Product.isTopSellable</code> attribute.
	 * @return the isTopSellable - isTopSellable
	 */
	public Boolean isIsTopSellable(final SessionContext ctx, final Product item)
	{
		return (Boolean)item.getProperty( ctx, TopsellableproductConstants.Attributes.Product.ISTOPSELLABLE);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Product.isTopSellable</code> attribute.
	 * @return the isTopSellable - isTopSellable
	 */
	public Boolean isIsTopSellable(final Product item)
	{
		return isIsTopSellable( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Product.isTopSellable</code> attribute. 
	 * @return the isTopSellable - isTopSellable
	 */
	public boolean isIsTopSellableAsPrimitive(final SessionContext ctx, final Product item)
	{
		Boolean value = isIsTopSellable( ctx,item );
		return value != null ? value.booleanValue() : false;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Product.isTopSellable</code> attribute. 
	 * @return the isTopSellable - isTopSellable
	 */
	public boolean isIsTopSellableAsPrimitive(final Product item)
	{
		return isIsTopSellableAsPrimitive( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Product.isTopSellable</code> attribute. 
	 * @param value the isTopSellable - isTopSellable
	 */
	public void setIsTopSellable(final SessionContext ctx, final Product item, final Boolean value)
	{
		item.setProperty(ctx, TopsellableproductConstants.Attributes.Product.ISTOPSELLABLE,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Product.isTopSellable</code> attribute. 
	 * @param value the isTopSellable - isTopSellable
	 */
	public void setIsTopSellable(final Product item, final Boolean value)
	{
		setIsTopSellable( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Product.isTopSellable</code> attribute. 
	 * @param value the isTopSellable - isTopSellable
	 */
	public void setIsTopSellable(final SessionContext ctx, final Product item, final boolean value)
	{
		setIsTopSellable( ctx, item, Boolean.valueOf( value ) );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Product.isTopSellable</code> attribute. 
	 * @param value the isTopSellable - isTopSellable
	 */
	public void setIsTopSellable(final Product item, final boolean value)
	{
		setIsTopSellable( getSession().getSessionContext(), item, value );
	}
	
}
